﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TH05___Shop
{
    public class DataCategory
    {
        public DataTable dtCategory { get; private set; }

        // Singleton pattern
        private static DataCategory instance;

        public static DataCategory Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new DataCategory();
                    instance.Initialize();
                }
                return instance;
            }
        }

        private void Initialize()
        {
            dtCategory = new DataTable();
            dtCategory.Columns.Add("ID Category");
            dtCategory.Columns.Add("Nama Category");
        }

        public void AddRow(string idcategory, string name)
        {
            dtCategory.Rows.Add(idcategory, name);
        }
    }
}
