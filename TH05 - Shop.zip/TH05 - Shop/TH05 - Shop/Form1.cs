﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH05___Shop
{
    public partial class Form1 : Form
    {
        DataTable dtProdukTampil;
        string idProduct = "";
        string idCategory = "";
        string idNamaCategory = "";
        string rowData = "";
        string rowDataCategory = "";
        List<string> filter = new List<string>();

        public Form1()
        {
            InitializeComponent();
            dtProdukTampil = new DataTable();
            dtProdukTampil.Columns.Add("ID Product");
            dtProdukTampil.Columns.Add("Nama Product");
            dtProdukTampil.Columns.Add("Harga");
            dtProdukTampil.Columns.Add("Stock");
            dtProdukTampil.Columns.Add("ID Category");

            dg_category.RowHeadersVisible = false;
            dg_product.RowHeadersVisible = false;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            DataSimpan.Instance.AddRow("J001" , "Jas Hitam" , "100000" , "10" , "C1");
            DataSimpan.Instance.AddRow("T001", "T-Shirt Black Pink", "70000", "20", "C2");
            DataSimpan.Instance.AddRow("T002", "T-Shirt Obsessive", "75000", "16", "C2");
            DataSimpan.Instance.AddRow("R001", "Rok Mini", "82000", "26", "C3");
            DataSimpan.Instance.AddRow("J002", "Jeans Biru", "90000", "5", "C4");
            DataSimpan.Instance.AddRow("C001", "Celana Pendek Coklat", "60000", "11", "C4");
            DataSimpan.Instance.AddRow("C002", "Cawat Blink-Blink", "1000000", "1", "C5");
            DataSimpan.Instance.AddRow("R002", "Rocca Shirt", "50000", "8", "C2");

            DataCategory.Instance.AddRow("C1", "Jas");
            DataCategory.Instance.AddRow("C2", "T-Shirt");
            DataCategory.Instance.AddRow("C3", "Rok");
            DataCategory.Instance.AddRow("C4", "Celana");
            DataCategory.Instance.AddRow("C5", "Cawat");

            cb_CategoryAdd();
            cb_filterAdd();
            cb_filter.Enabled = false;
            dg_product.ClearSelection();
            dg_category.ClearSelection();
            dg_product.Columns["Nama Product"].Width = 100;
            dg_product.Columns["Stock"].Width = 50;
            dg_product.Columns["Harga"].Width = 60;
            dg_product.DataSource = DataSimpan.Instance.dtProdukSimpan;
            dg_category.DataSource = DataCategory.Instance.dtCategory;
        }
        void cb_CategoryAdd()
        {
            for (int i = 0; i < DataCategory.Instance.dtCategory.Columns.Count; i++)
            {
                for (int j = 0; j < DataCategory.Instance.dtCategory.Rows.Count; j++)
                {
                    cb_category.Items.Add(DataCategory.Instance.dtCategory.Rows[j][1]);
                }
                break;
            }
        }

        void cb_filterAdd()
        {
            filter.Clear();
            for (int i = 0; i < DataCategory.Instance.dtCategory.Rows.Count; i++)
            {
                filter.Add(DataCategory.Instance.dtCategory.Rows[i][1].ToString());
            }
            cb_filter.DataSource = null;
            cb_filter.DataSource = filter;
            cb_filter.SelectedIndex = -1;
            dg_product.DataSource = DataSimpan.Instance.dtProdukSimpan;
        }

//BUTTON FILTER COMBOBOX DAN ALL
        private void btn_filter_Click(object sender, EventArgs e)
        {
            //nampilin isi combobox filter
            cb_filter.Enabled = true;
            cb_filter.DataSource = filter;
            cb_filter.SelectedIndex = -1;

        }

        private void cb_filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            //jika filter yg dipilih sama dengan data di category ambil id category
            if (cb_filter.SelectedIndex >= 0)
            {
                dtProdukTampil.Rows.Clear();
                var selectedCategory = cb_filter.SelectedItem.ToString();
                string idcategory = "";
                for (int i = 0; i < DataCategory.Instance.dtCategory.Columns.Count; i++)
                {
                    for (int j = 0; j < DataCategory.Instance.dtCategory.Rows.Count; j++)
                    {
                        if (selectedCategory == DataCategory.Instance.dtCategory.Rows[j][1].ToString())
                        {
                            idcategory = DataCategory.Instance.dtCategory.Rows[j][0].ToString(); //C1
                        }
                    }
                    break;
                }
                //nampilin di data grid jika id category dataCategory = id category di dataSimpan
                for (int i = 0; i < DataSimpan.Instance.dtProdukSimpan.Columns.Count; i++)
                {
                    for (int j = 0; j < DataSimpan.Instance.dtProdukSimpan.Rows.Count; j++)
                    {
                        if (idcategory == DataSimpan.Instance.dtProdukSimpan.Rows[j][4].ToString())
                        {
                            dtProdukTampil.Rows.Add(DataSimpan.Instance.dtProdukSimpan.Rows[j][0],
                                DataSimpan.Instance.dtProdukSimpan.Rows[j][1],
                                DataSimpan.Instance.dtProdukSimpan.Rows[j][2],
                                DataSimpan.Instance.dtProdukSimpan.Rows[j][3],
                                DataSimpan.Instance.dtProdukSimpan.Rows[j][4]);
                            dg_product.DataSource = dtProdukTampil;
                        }                      
                    }
                    break;
                }
            }
        }

        private void btn_All_Click(object sender, EventArgs e)
        {
            dg_product.DataSource = DataSimpan.Instance.dtProdukSimpan;
            cb_filter.SelectedIndex = -1;
            cb_filter.Enabled = false;
        }

//DATAGRID PRODUK ADD
        private void tb_nama_TextChanged(object sender, EventArgs e)
        {
            if (tb_nama.Text != "")
            {
                int count = 1;
                string namaProduct = tb_nama.Text;
                string hurufDepan = namaProduct[0].ToString().ToUpper();
                foreach (DataGridViewRow dgvr in dg_product.Rows)
                {
                    int currentID = int.Parse(dgvr.Cells[0].Value.ToString().Substring(1));//angka terakhir
                    if (hurufDepan == dgvr.Cells[0].Value.ToString().Substring(0, 1))
                    {
                        if (currentID >= count)
                        {
                            count = currentID + 1;
                        }
                    }
                }
                string formatNum = count.ToString("000");
                idProduct = hurufDepan + formatNum;
            }
        }

        private void cb_category_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_category.Text != "")
            {
                var categoryPilih = cb_category.Text;
                string idcategory = "";
                for (int i = 0; i < DataCategory.Instance.dtCategory.Columns.Count; i++)
                {
                    for (int j = 0; j < DataCategory.Instance.dtCategory.Rows.Count; j++)
                    {
                        if (categoryPilih == DataCategory.Instance.dtCategory.Rows[j][1].ToString())
                        {
                            idcategory = DataCategory.Instance.dtCategory.Rows[j][0].ToString(); //C1
                        }
                    }
                    break;
                }
                idCategory = idcategory;
            }
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            //bikin eror
            bool exit = true;
            if (tb_nama.Text == "" || tb_harga.Text == "" || cb_category.Text == "" || tb_stock.Text == "")
            {
                MessageBox.Show("Fields are not properly field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                exit = false;
            }
            if (exit == true)
            {
                DataSimpan.Instance.AddRow(idProduct, tb_nama.Text, tb_harga.Text, tb_stock.Text, idCategory);
                tb_nama.Text = "";
                tb_harga.Text = "";
                tb_stock.Text = "";
                cb_category.SelectedIndex = -1;
            }
            idProduct = "";
            idCategory = "";
        }

//HARUS PRESS ANGKA
        private void tb_harga_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tb_stock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

//DATAGIRD ADD CATEGORY
        private void tb_namacategory_TextChanged(object sender, EventArgs e)
        {
            if (tb_namacategory.Text != "")
            {
                int angkaID = 1;
                foreach (DataGridViewRow row in dg_category.Rows)
                {
                    int currentID = int.Parse(row.Cells[0].Value.ToString().Substring(1));
                    if (currentID >= angkaID)
                    {
                        angkaID = currentID + 1;
                    }
                }
                idNamaCategory = "C" + angkaID;
            }
        }

        private void btn_addcategory_Click(object sender, EventArgs e)
        {
            //bikin eror
            bool exit = true;
            if (tb_namacategory.Text == "")
            {
                MessageBox.Show("Fields are not properly field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                exit = false;
            }
            if (tb_namacategory.Text != null)
            {
                for (int i = 0; i < DataCategory.Instance.dtCategory.Columns.Count; i++)
                {
                    for (int j = 0; j < DataCategory.Instance.dtCategory.Rows.Count; j++)
                    {
                        if (tb_namacategory.Text == DataCategory.Instance.dtCategory.Rows[j][1].ToString())
                        {
                            MessageBox.Show("Category name already exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            exit = false;
                        }
                    }
                    break;
                }
            }
            if (exit == true)
            {
                DataCategory.Instance.AddRow(idNamaCategory, tb_namacategory.Text);
                tb_namacategory.Text = "";
                int jml = dg_category.Rows.Count;
                cb_category.Items.Add(DataCategory.Instance.dtCategory.Rows[jml - 1][1].ToString());

                filter.Add(DataCategory.Instance.dtCategory.Rows[jml - 1][1].ToString());
                filter.Clear();
                cb_filterAdd();
            }
            idNamaCategory = "";
        }

//AMBIL DAN EDIT PRODUK

        private void dg_product_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                rowData = dg_product.Rows[e.RowIndex].Cells[0].Value.ToString(); // J001
                string idCategoryData = dg_product.Rows[e.RowIndex].Cells[4].Value.ToString(); //C1
                string masuknamaCategory = "";

                for (int i = 0; i < DataCategory.Instance.dtCategory.Columns.Count; i++)
                {
                    for (int j = 0; j < DataCategory.Instance.dtCategory.Rows.Count; j++)
                    {
                        if (idCategoryData == DataCategory.Instance.dtCategory.Rows[j][0].ToString())
                        {
                            masuknamaCategory = DataCategory.Instance.dtCategory.Rows[j][01].ToString(); //JAS
                        }
                    }
                    break;
                }
                for (int i = 0; i < DataSimpan.Instance.dtProdukSimpan.Columns.Count; i++)
                {
                    for (int j = 0; j < DataSimpan.Instance.dtProdukSimpan.Rows.Count; j++)
                    {
                        if (rowData == DataSimpan.Instance.dtProdukSimpan.Rows[j][i].ToString())
                        {
                            tb_nama.Text = DataSimpan.Instance.dtProdukSimpan.Rows[j][1].ToString();
                            cb_category.Text = masuknamaCategory;
                            tb_harga.Text = DataSimpan.Instance.dtProdukSimpan.Rows[j][2].ToString();
                            tb_stock.Text = DataSimpan.Instance.dtProdukSimpan.Rows[j][3].ToString();
                        }
                    }
                    break;
                }
            }
        }

        private void btn_edit_Click(object sender, EventArgs e)
        {
            //bikin eror
            bool exit = true;
            if (tb_nama.Text == "" || tb_harga.Text == "" || cb_category.Text == "" || tb_stock.Text == "")
            {
                MessageBox.Show("Choose a product first", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                exit = false;
            }
            //remove stok 0 
            if (tb_stock.Text == "0")
            {
                if (cb_category.SelectedIndex >= 0)
                {
                    for (int i = 0; i < DataSimpan.Instance.dtProdukSimpan.Columns.Count; i++)
                    {
                        for (int j = 0; j < DataSimpan.Instance.dtProdukSimpan.Rows.Count; j++)
                        {
                            if (rowData == DataSimpan.Instance.dtProdukSimpan.Rows[j][0].ToString())
                            {
                                DataSimpan.Instance.dtProdukSimpan.Rows.RemoveAt(j);
                            }
                        }
                        break;
                    }
                    tb_nama.Text = "";
                    tb_harga.Text = "";
                    tb_stock.Text = "";
                    cb_category.SelectedIndex = -1;
                    exit = false;
                }
            }
            if (exit == true)
            {
                if (cb_category.SelectedIndex >= 0)
                {
                    for (int i = 0; i < DataSimpan.Instance.dtProdukSimpan.Columns.Count; i++)
                    {
                        for (int j = 0; j < DataSimpan.Instance.dtProdukSimpan.Rows.Count; j++)
                        {
                            if (rowData == DataSimpan.Instance.dtProdukSimpan.Rows[j][0].ToString())
                            {
                                DataSimpan.Instance.dtProdukSimpan.Rows[j][1] = tb_nama.Text;
                                DataSimpan.Instance.dtProdukSimpan.Rows[j][2] = tb_harga.Text;
                                DataSimpan.Instance.dtProdukSimpan.Rows[j][3] = tb_stock.Text;
                                DataSimpan.Instance.dtProdukSimpan.Rows[j][4] = idCategory;
                            }
                        }
                        break;
                    }
                    tb_nama.Text = "";
                    tb_harga.Text = "";
                    tb_stock.Text = "";
                    cb_category.SelectedIndex = -1;
                }
            }
            idCategory = "";
        }

 //REMOVE PRODUCT
        private void btn_remove_Click(object sender, EventArgs e)
        {
            if (cb_category.SelectedIndex >= 0)
            {
                for (int i = 0; i < DataSimpan.Instance.dtProdukSimpan.Columns.Count; i++)
                {
                    for (int j = 0; j < DataSimpan.Instance.dtProdukSimpan.Rows.Count; j++)
                    {
                        if (rowData == DataSimpan.Instance.dtProdukSimpan.Rows[j][0].ToString())
                        {
                            DataSimpan.Instance.dtProdukSimpan.Rows.RemoveAt(j);
                        }
                    }
                    break;
                }
                tb_nama.Text = "";
                tb_harga.Text = "";
                tb_stock.Text = "";
                cb_category.SelectedIndex = -1;
            }
        }

//AMBIL DAN REMOVE CATEGORY
        private void btn_removeCategory_Click(object sender, EventArgs e)
        {
            bool exit = true;
            string namaCategorynya = "";
            if (tb_namacategory.Text == "")
            {
                MessageBox.Show("Choose category first.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                exit = false;
            }
            if (exit == true)
            {
                //remove category
                for (int i = 0; i < DataCategory.Instance.dtCategory.Columns.Count; i++)
                {
                    for (int j = 0; j < DataCategory.Instance.dtCategory.Rows.Count; j++)
                    {
                        if (rowDataCategory == DataCategory.Instance.dtCategory.Rows[j][0].ToString()) // C3
                        {
                            DataCategory.Instance.dtCategory.Rows.RemoveAt(j);
                        }
                    }
                    break;
                }
                //remove produk 
                for (int i = 0; i < DataSimpan.Instance.dtProdukSimpan.Columns.Count; i++)
                {
                    for (int j = 0; j < DataSimpan.Instance.dtProdukSimpan.Rows.Count; j++)
                    {
                        if (rowDataCategory == DataSimpan.Instance.dtProdukSimpan.Rows[j][4].ToString())
                        {
                            DataSimpan.Instance.dtProdukSimpan.Rows.RemoveAt(j); 
                        }
                    }
                    break;
                }
                //ambil nama
                for (int i = 0; i < DataCategory.Instance.dtCategory.Columns.Count; i++)
                {
                    for (int j = 0; j < DataCategory.Instance.dtCategory.Rows.Count; j++)
                    {
                        if (rowDataCategory == DataCategory.Instance.dtCategory.Rows[j][0].ToString())
                        {
                            namaCategorynya = DataCategory.Instance.dtCategory.Rows[j][1].ToString(); //JAS
                        }
                    }
                    break;
                }
                cb_category.Items.Remove(namaCategorynya);
                cb_category.Items.Clear();
                cb_CategoryAdd();

                filter.Remove(namaCategorynya);
                filter.Clear();
                cb_filterAdd();
                cb_filter.SelectedIndex = -1;
                tb_namacategory.Text = "";
            }
        }

        private void dg_category_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                rowDataCategory = dg_category.Rows[e.RowIndex].Cells[0].Value.ToString(); //C3
                for (int i = 0; i < DataCategory.Instance.dtCategory.Columns.Count; i++)
                {
                    for (int j = 0; j < DataCategory.Instance.dtCategory.Rows.Count; j++)
                    {
                        if (rowDataCategory == DataCategory.Instance.dtCategory.Rows[j][0].ToString())
                        {
                            tb_namacategory.Text = DataCategory.Instance.dtCategory.Rows[j][1].ToString(); //JAS
                        }
                    }
                    break;
                }
            }
        }
    }
}
