﻿namespace TH05___Shop
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lb_product = new System.Windows.Forms.Label();
            this.lb_category = new System.Windows.Forms.Label();
            this.btn_All = new System.Windows.Forms.Button();
            this.btn_filter = new System.Windows.Forms.Button();
            this.cb_filter = new System.Windows.Forms.ComboBox();
            this.dg_product = new System.Windows.Forms.DataGridView();
            this.dg_category = new System.Windows.Forms.DataGridView();
            this.lb_details = new System.Windows.Forms.Label();
            this.lb_nama = new System.Windows.Forms.Label();
            this.lb_cat = new System.Windows.Forms.Label();
            this.lb_harga = new System.Windows.Forms.Label();
            this.lb_stock = new System.Windows.Forms.Label();
            this.cb_category = new System.Windows.Forms.ComboBox();
            this.tb_nama = new System.Windows.Forms.TextBox();
            this.tb_harga = new System.Windows.Forms.TextBox();
            this.tb_stock = new System.Windows.Forms.TextBox();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_edit = new System.Windows.Forms.Button();
            this.btn_remove = new System.Windows.Forms.Button();
            this.lb_namacat = new System.Windows.Forms.Label();
            this.tb_namacategory = new System.Windows.Forms.TextBox();
            this.btn_addcategory = new System.Windows.Forms.Button();
            this.btn_removeCategory = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dg_product)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dg_category)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_product
            // 
            this.lb_product.AutoSize = true;
            this.lb_product.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_product.Location = new System.Drawing.Point(27, 27);
            this.lb_product.Name = "lb_product";
            this.lb_product.Size = new System.Drawing.Size(119, 32);
            this.lb_product.TabIndex = 0;
            this.lb_product.Text = "Product";
            // 
            // lb_category
            // 
            this.lb_category.AutoSize = true;
            this.lb_category.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_category.Location = new System.Drawing.Point(576, 27);
            this.lb_category.Name = "lb_category";
            this.lb_category.Size = new System.Drawing.Size(137, 32);
            this.lb_category.TabIndex = 1;
            this.lb_category.Text = "Category";
            // 
            // btn_All
            // 
            this.btn_All.Location = new System.Drawing.Point(283, 42);
            this.btn_All.Name = "btn_All";
            this.btn_All.Size = new System.Drawing.Size(70, 32);
            this.btn_All.TabIndex = 2;
            this.btn_All.Text = "All";
            this.btn_All.UseVisualStyleBackColor = true;
            this.btn_All.Click += new System.EventHandler(this.btn_All_Click);
            // 
            // btn_filter
            // 
            this.btn_filter.Location = new System.Drawing.Point(359, 42);
            this.btn_filter.Name = "btn_filter";
            this.btn_filter.Size = new System.Drawing.Size(70, 32);
            this.btn_filter.TabIndex = 3;
            this.btn_filter.Text = "Filter";
            this.btn_filter.UseVisualStyleBackColor = true;
            this.btn_filter.Click += new System.EventHandler(this.btn_filter_Click);
            // 
            // cb_filter
            // 
            this.cb_filter.BackColor = System.Drawing.SystemColors.Control;
            this.cb_filter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_filter.FormattingEnabled = true;
            this.cb_filter.Location = new System.Drawing.Point(435, 42);
            this.cb_filter.Name = "cb_filter";
            this.cb_filter.Size = new System.Drawing.Size(121, 28);
            this.cb_filter.TabIndex = 4;
            this.cb_filter.SelectedIndexChanged += new System.EventHandler(this.cb_filter_SelectedIndexChanged);
            // 
            // dg_product
            // 
            this.dg_product.AllowUserToAddRows = false;
            this.dg_product.AllowUserToDeleteRows = false;
            this.dg_product.AllowUserToResizeColumns = false;
            this.dg_product.AllowUserToResizeRows = false;
            this.dg_product.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dg_product.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dg_product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dg_product.DefaultCellStyle = dataGridViewCellStyle1;
            this.dg_product.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dg_product.Location = new System.Drawing.Point(33, 80);
            this.dg_product.Name = "dg_product";
            this.dg_product.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dg_product.RowHeadersWidth = 5;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dg_product.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dg_product.RowTemplate.Height = 28;
            this.dg_product.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dg_product.Size = new System.Drawing.Size(523, 369);
            this.dg_product.TabIndex = 5;
            this.dg_product.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dg_product_CellClick);
            // 
            // dg_category
            // 
            this.dg_category.AllowUserToAddRows = false;
            this.dg_category.AllowUserToDeleteRows = false;
            this.dg_category.AllowUserToResizeColumns = false;
            this.dg_category.AllowUserToResizeRows = false;
            this.dg_category.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dg_category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_category.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dg_category.Location = new System.Drawing.Point(582, 80);
            this.dg_category.Name = "dg_category";
            this.dg_category.RowHeadersWidth = 62;
            this.dg_category.RowTemplate.Height = 28;
            this.dg_category.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dg_category.Size = new System.Drawing.Size(325, 275);
            this.dg_category.TabIndex = 6;
            this.dg_category.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dg_category_CellClick);
            // 
            // lb_details
            // 
            this.lb_details.AutoSize = true;
            this.lb_details.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_details.Location = new System.Drawing.Point(27, 466);
            this.lb_details.Name = "lb_details";
            this.lb_details.Size = new System.Drawing.Size(109, 32);
            this.lb_details.TabIndex = 7;
            this.lb_details.Text = "Details";
            // 
            // lb_nama
            // 
            this.lb_nama.AutoSize = true;
            this.lb_nama.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nama.Location = new System.Drawing.Point(36, 511);
            this.lb_nama.Name = "lb_nama";
            this.lb_nama.Size = new System.Drawing.Size(67, 22);
            this.lb_nama.TabIndex = 8;
            this.lb_nama.Text = "Name: ";
            // 
            // lb_cat
            // 
            this.lb_cat.AutoSize = true;
            this.lb_cat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_cat.Location = new System.Drawing.Point(12, 551);
            this.lb_cat.Name = "lb_cat";
            this.lb_cat.Size = new System.Drawing.Size(88, 22);
            this.lb_cat.TabIndex = 9;
            this.lb_cat.Text = "Category:";
            // 
            // lb_harga
            // 
            this.lb_harga.AutoSize = true;
            this.lb_harga.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_harga.Location = new System.Drawing.Point(36, 595);
            this.lb_harga.Name = "lb_harga";
            this.lb_harga.Size = new System.Drawing.Size(64, 22);
            this.lb_harga.TabIndex = 10;
            this.lb_harga.Text = "Harga:";
            // 
            // lb_stock
            // 
            this.lb_stock.AutoSize = true;
            this.lb_stock.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_stock.Location = new System.Drawing.Point(38, 635);
            this.lb_stock.Name = "lb_stock";
            this.lb_stock.Size = new System.Drawing.Size(65, 22);
            this.lb_stock.TabIndex = 11;
            this.lb_stock.Text = "Stock: ";
            // 
            // cb_category
            // 
            this.cb_category.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_category.FormattingEnabled = true;
            this.cb_category.Location = new System.Drawing.Point(106, 551);
            this.cb_category.Name = "cb_category";
            this.cb_category.Size = new System.Drawing.Size(162, 28);
            this.cb_category.TabIndex = 12;
            this.cb_category.SelectedIndexChanged += new System.EventHandler(this.cb_category_SelectedIndexChanged);
            // 
            // tb_nama
            // 
            this.tb_nama.Location = new System.Drawing.Point(106, 511);
            this.tb_nama.Name = "tb_nama";
            this.tb_nama.Size = new System.Drawing.Size(464, 26);
            this.tb_nama.TabIndex = 13;
            this.tb_nama.TextChanged += new System.EventHandler(this.tb_nama_TextChanged);
            // 
            // tb_harga
            // 
            this.tb_harga.Location = new System.Drawing.Point(106, 591);
            this.tb_harga.Name = "tb_harga";
            this.tb_harga.Size = new System.Drawing.Size(163, 26);
            this.tb_harga.TabIndex = 14;
            this.tb_harga.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_harga_KeyPress);
            // 
            // tb_stock
            // 
            this.tb_stock.Location = new System.Drawing.Point(106, 635);
            this.tb_stock.Name = "tb_stock";
            this.tb_stock.Size = new System.Drawing.Size(163, 26);
            this.tb_stock.TabIndex = 15;
            this.tb_stock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_stock_KeyPress);
            // 
            // btn_add
            // 
            this.btn_add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btn_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_add.Location = new System.Drawing.Point(282, 551);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(88, 74);
            this.btn_add.TabIndex = 16;
            this.btn_add.Text = "Add Product";
            this.btn_add.UseVisualStyleBackColor = false;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_edit
            // 
            this.btn_edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btn_edit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_edit.Location = new System.Drawing.Point(376, 551);
            this.btn_edit.Name = "btn_edit";
            this.btn_edit.Size = new System.Drawing.Size(88, 74);
            this.btn_edit.TabIndex = 17;
            this.btn_edit.Text = "Edit Product";
            this.btn_edit.UseVisualStyleBackColor = false;
            this.btn_edit.Click += new System.EventHandler(this.btn_edit_Click);
            // 
            // btn_remove
            // 
            this.btn_remove.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btn_remove.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_remove.Location = new System.Drawing.Point(469, 551);
            this.btn_remove.Name = "btn_remove";
            this.btn_remove.Size = new System.Drawing.Size(103, 74);
            this.btn_remove.TabIndex = 18;
            this.btn_remove.Text = "Remove Product";
            this.btn_remove.UseVisualStyleBackColor = false;
            this.btn_remove.Click += new System.EventHandler(this.btn_remove_Click);
            // 
            // lb_namacat
            // 
            this.lb_namacat.AutoSize = true;
            this.lb_namacat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_namacat.Location = new System.Drawing.Point(578, 392);
            this.lb_namacat.Name = "lb_namacat";
            this.lb_namacat.Size = new System.Drawing.Size(67, 22);
            this.lb_namacat.TabIndex = 19;
            this.lb_namacat.Text = "Name: ";
            // 
            // tb_namacategory
            // 
            this.tb_namacategory.Location = new System.Drawing.Point(652, 392);
            this.tb_namacategory.Name = "tb_namacategory";
            this.tb_namacategory.Size = new System.Drawing.Size(255, 26);
            this.tb_namacategory.TabIndex = 20;
            this.tb_namacategory.TextChanged += new System.EventHandler(this.tb_namacategory_TextChanged);
            // 
            // btn_addcategory
            // 
            this.btn_addcategory.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btn_addcategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_addcategory.Location = new System.Drawing.Point(679, 438);
            this.btn_addcategory.Name = "btn_addcategory";
            this.btn_addcategory.Size = new System.Drawing.Size(111, 74);
            this.btn_addcategory.TabIndex = 21;
            this.btn_addcategory.Text = "Add Category";
            this.btn_addcategory.UseVisualStyleBackColor = false;
            this.btn_addcategory.Click += new System.EventHandler(this.btn_addcategory_Click);
            // 
            // btn_removeCategory
            // 
            this.btn_removeCategory.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btn_removeCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_removeCategory.Location = new System.Drawing.Point(796, 438);
            this.btn_removeCategory.Name = "btn_removeCategory";
            this.btn_removeCategory.Size = new System.Drawing.Size(111, 74);
            this.btn_removeCategory.TabIndex = 22;
            this.btn_removeCategory.Text = "Remove Category";
            this.btn_removeCategory.UseVisualStyleBackColor = false;
            this.btn_removeCategory.Click += new System.EventHandler(this.btn_removeCategory_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::TH05___Shop.Properties.Resources._469_4691308_bongo_cat_my_doods_bongo_cat_png_transparent_removebg_preview2;
            this.pictureBox1.Location = new System.Drawing.Point(611, 527);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(328, 220);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 23;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(932, 685);
            this.Controls.Add(this.btn_removeCategory);
            this.Controls.Add(this.btn_addcategory);
            this.Controls.Add(this.tb_namacategory);
            this.Controls.Add(this.lb_namacat);
            this.Controls.Add(this.btn_remove);
            this.Controls.Add(this.btn_edit);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.tb_stock);
            this.Controls.Add(this.tb_harga);
            this.Controls.Add(this.tb_nama);
            this.Controls.Add(this.cb_category);
            this.Controls.Add(this.lb_stock);
            this.Controls.Add(this.lb_harga);
            this.Controls.Add(this.lb_cat);
            this.Controls.Add(this.lb_nama);
            this.Controls.Add(this.lb_details);
            this.Controls.Add(this.dg_category);
            this.Controls.Add(this.dg_product);
            this.Controls.Add(this.cb_filter);
            this.Controls.Add(this.btn_filter);
            this.Controls.Add(this.btn_All);
            this.Controls.Add(this.lb_category);
            this.Controls.Add(this.lb_product);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Blink Shop";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dg_product)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dg_category)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_product;
        private System.Windows.Forms.Label lb_category;
        private System.Windows.Forms.Button btn_All;
        private System.Windows.Forms.Button btn_filter;
        private System.Windows.Forms.ComboBox cb_filter;
        private System.Windows.Forms.DataGridView dg_product;
        private System.Windows.Forms.DataGridView dg_category;
        private System.Windows.Forms.Label lb_details;
        private System.Windows.Forms.Label lb_nama;
        private System.Windows.Forms.Label lb_cat;
        private System.Windows.Forms.Label lb_harga;
        private System.Windows.Forms.Label lb_stock;
        private System.Windows.Forms.ComboBox cb_category;
        private System.Windows.Forms.TextBox tb_nama;
        private System.Windows.Forms.TextBox tb_harga;
        private System.Windows.Forms.TextBox tb_stock;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_edit;
        private System.Windows.Forms.Button btn_remove;
        private System.Windows.Forms.Label lb_namacat;
        private System.Windows.Forms.TextBox tb_namacategory;
        private System.Windows.Forms.Button btn_addcategory;
        private System.Windows.Forms.Button btn_removeCategory;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

