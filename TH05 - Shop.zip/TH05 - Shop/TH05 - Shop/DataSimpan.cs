﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TH05___Shop
{
    public class DataSimpan
    {
        public DataTable dtProdukSimpan { get; private set; }

        // Singleton pattern
        private static DataSimpan instance;

        public static DataSimpan Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new DataSimpan();
                    instance.Initialize();
                }
                return instance;
            }
        }

        private void Initialize()
        {
            dtProdukSimpan = new DataTable();
            dtProdukSimpan.Columns.Add("ID Product");
            dtProdukSimpan.Columns.Add("Nama Product");
            dtProdukSimpan.Columns.Add("Harga");
            dtProdukSimpan.Columns.Add("Stock");
            dtProdukSimpan.Columns.Add("ID Category");

        }

        public void AddRow(string idproduct, string name, string harga, string stock, string idcategory )
        {
            dtProdukSimpan.Rows.Add(idproduct, name, harga, stock, idcategory);
        }
    }
}
